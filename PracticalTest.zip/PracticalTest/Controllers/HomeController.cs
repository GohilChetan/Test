﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using PracticalTest.Models;

namespace PracticalTest.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult Dashboard()
        {
            return View();
        }

        public ActionResult AddUserDetail()
        {
            return View(new User());
        }
        [HttpPost]
        public ActionResult AddUserDetail(User obj)
        {
            TempData["User"] = obj;
            return RedirectToAction("UserDetail", "Home");
        }

        public ActionResult UserDetail()
        {
            if(TempData["User"] != null)
            {
                User _user = TempData["User"] as User;
                return View(_user);
            }
            else
            {
                return View(new User() { ErrorMessage = "User Detail Not Available."});
            }
        }
    }
}