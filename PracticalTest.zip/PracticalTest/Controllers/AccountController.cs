﻿using PracticalTest.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace PracticalTest.Controllers
{
    public class AccountController : Controller
    {
        // GET: Account
        public ActionResult Login()
        {
            return View(new Login());
        }

        [HttpPost]
        public ActionResult Login(Login objUser)
        {
            if (ModelState.IsValid)
            {
                if(objUser.UserName == "Admin")
                {
                    if(objUser.Password == "Admin@123")
                    {
                        Session["UserName"] = objUser.UserName.ToString();
                        return RedirectToAction("Dashboard","Home");
                    }
                    else
                    {
                        objUser.ErrorMessage = "Password is Wrong.";
                    }                    
                }   
                else
                {
                    objUser.ErrorMessage = "UserName is Wrong.";
                }
            }
            return View(objUser);
        }
    }
}